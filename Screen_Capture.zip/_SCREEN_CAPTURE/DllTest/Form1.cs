﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using _SCREEN_CAPTURE;

namespace DllTest
{
    public partial class Form1 : Form
    {
        public Form1() {
            InitializeComponent();
            //this.Enabled = false;
            this.FormClosed += (s, e) => this.Dispose();
        }
        ~Form1() {
            MessageBox.Show("test");
        }

        private void Form1_Load(object sender, EventArgs e) {
            //this.Enabled = false;
            //MessageBox.Show(toolButton1.IsSelected.ToString());
        }

        private void Form1_Paint(object sender, PaintEventArgs e) {
   
        }

        private void button1_Click_1(object sender, EventArgs e) {
            FrmCapture frmC = new FrmCapture();
            frmC.Show();
        }

    }
}
